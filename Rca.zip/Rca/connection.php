
<?php
$servername="localhost";//127.0.0.1
$username="root";
$password="root";
$dbname="student_db";
$conn=new mysqli($servername,$username,$password,$dbname);
    if(!$conn){
        echo "connection failed!!!";
    }
?>