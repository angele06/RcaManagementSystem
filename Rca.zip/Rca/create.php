<?php
include 'connection.php';

if (isset($_POST['create'])) {
    $names = $_POST['names'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $class = $_POST['class'];
    $address = $_POST['address'];

 $sql = "INSERT INTO rca(names,email,gender,class,address) VALUES('$names','$email','$gender','$class','$address')";
 $result=$conn->query($sql);
 if($result){
 header("Location: list.php");
        } 
        else{
            echo 'error:'.$sql.'<br>'.$conn->error;
        }
        $conn->close();
        }
  ?>
