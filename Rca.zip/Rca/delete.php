<?php
include 'connection.php';

if(isset($_GET['id'])){
    $id=$_GET['id'];
$sql = "DELETE FROM rca WHERE id =$id";

$res = $conn->query($sql);

if ($res) {
    Header("Location:list.php");
} else {
    echo 'error:'.$sql.'<br>'.$conn->error; 
}
}
?>
