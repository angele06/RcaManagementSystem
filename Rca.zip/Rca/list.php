<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <header class="d-flex justify-content-between my-4">
            <h1>Students List</h1>
     <div>
        <a href="register.php" class="btn btn-primary">New Student</a>
        <a href="pdf.php" name="view"class="btn btn-info">Get pdf document</a>
        <a href="export.php" class="btn btn-success"><i class="dwn"></i>Download csv</a>


    </div>
    </header>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Student Id</th>
                <th>Names</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Class</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php
          include "connection.php";
          $sql="SELECT * FROM rca";
          $res=$conn->query($sql);
         while($row=mysqli_fetch_array($res)){
?>
<tr>
    <td><?php echo $row["id"];?></td>
    <td><?php echo $row["names"];?></td>
    <td><?php echo $row["email"];?></td>
    <td><?php echo $row["gender"];?></td>
    <td><?php echo $row["class"];?></td>
    <td><?php echo $row["address"];?></td>

    <td>
        <a href="edit.php?id=<?php echo $row["id"];?>" class="btn btn-warning">Edit</a>
        <a href="delete.php?id=<?php echo $row["id"];?>" name="delete" class="btn btn-danger">Delete</a>
                 </td>
</tr>
<?php

         };
?>
      
        </tbody>
    </table>
</body>
</html>