<?php
 include "connection.php"; 
    if(isset($_POST['edit'])){
        $id=$_POST['id'];
        $names=$_POST['names'];
        $email=$_POST['email'];  
        $gender=$_POST['gender'];
        $class=$_POST['class'];
        $address=$_POST['address'];

        $sql="UPDATE rca SET names='$names',email='$email',gender='$gender',class='$class',address='$address' WHERE id='$id'";
        $result=$conn->query($sql);
        if($result){   
        Header('Location:list.php');
            }else{
            echo 'error:'.$ql.'<br>'.$conn->error;
        }
    $conn->close();
    }

?>