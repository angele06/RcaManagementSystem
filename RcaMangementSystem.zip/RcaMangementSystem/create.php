<?php
include 'connection.php';

if (isset($_POST['create'])) {
    $names = $_POST['names'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $class = $_POST['class'];
    $address = $_POST['address'];
    $password = Md5($_POST['address']);


 $sql = "INSERT INTO rca(names,email,gender,class,address,password) VALUES('$names','$email','$gender','$class','$address','$password')";
 $result=$conn->query($sql);
 if($result){
 header("Location: list.php");
        } 
        else{
            echo 'error:'.$sql.'<br>'.$conn->error;
        }
        $conn->close();
        }
  ?>
