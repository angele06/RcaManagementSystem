<?php

include "connection.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $email=$_POST["email"];
    $password=Md5($_POST["password"]);    
    $result=$conn->query("SELECT * FROM rca WHERE email='$email' AND password='$password'");

if($result){
      header('Location:list.php');
        
    }else{
     echo "invalid creadentials";
        
    exit();
    }
}

if($result->num_rows>0){
    
    session_start();
    $_SESSION["email"]=$email;

    header("Location:list.php");
    exit();
}else{

    echo "Invalid username or password";
}

?>
